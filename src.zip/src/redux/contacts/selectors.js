export const getTasks = state => state.users.items;
export const getLoading = state => state.users.isLoading;
export const errorMessage = state => state.users.error;
export const getStatusFilter = state => state.users.filter;
